#include <stdio.h>


enum degree_program{ SECURITY, NETWORK, SOFTWARE };
